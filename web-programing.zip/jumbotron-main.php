<div class="jumbotron jumbotron-fluid">
  <div class="jumbotron-child-1">
      <div class="container jumbotron-content-main">
            <h1>Sambut Kemenangan #Bersam4th ITConsultant.com</h1>
            <h4>Nikmati Pelayanan Terbaik, Ciptakan Suksesmu disini!</h4>
            <button class="btn btn-primary"><a href="promo.php">PROMO DISKON 50%</a></button>
      </div>
  </div>
</div> 