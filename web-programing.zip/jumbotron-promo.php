<div class="jumbotron jumbotron-fluid">
  <div class="jumbotron-child-pro">
      <div class="container jumbotron-content-main text-center">
            <h1>PROMO</h1>
            <p>Dapatkan Penawaran Promo Menarik, Jangan sampai kelewatan!</p>
      </div>
  </div>
</div>