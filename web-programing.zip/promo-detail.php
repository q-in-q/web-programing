<?php 
include("header.php");
include("jumbotron-promo-detail.php");
?>
<div class="container">
    
    <div class="main-promo-detail text-center">
        <img src="./assets/img/conjuly1plus.jpg" alt="">
        <div class="row">
        <div class="col">
            <div class="promo-hitung-mundur promo-habis">
                <i class="far fa-clock"></i><p>Promo Telah Berakhir</p>
            </div>
        </div>
        <div class="col">
        </div>
    </div>
        <p>IDcloudhost merupakan salah satu REGISTRAR Resmi dari PANDI untuk Domain Indonesia. Oleh karena itu kami senantiasa akan terus memberikan kepercayaan kepada Anda untuk memberikan layanan Domain Indonesia dengan harga yang terjangkau dan Proses yang sangat mudah untuk bisa mengamankan Brand Domain Indonesia Anda. Yuk Cinta domain Indonesia mulai saat ini, Kita memberikan penawaran Promo Domain ID Super murah Se-Indonesia Beli dan Transfer dengan Harga Rp 107.000 untuk setahun!.</p>

        <p>Lihat syarat dan ketentuan Promo <span> <a href="syarat-ketentuan-diskon.php">di sini</a> </span> </p>
        
        <div id="loading-overlay">
            <p>Please wait</p>
        </div>
        <div id="container">
            <button class="btn-grad btn-grad-1" ><i class="fas fa-check"></i> APPLY NOW</button>
            <button id="slow-load" class="btn-grad btn-grad-4" ><i class="fas fa-sync-alt"></i> RELOAD PAGE</button>
        </div>
    </div>
</div>
<div class="fullwidth-layout main-promo-footer">
    <div class="container text-center">
        <h1>promo lainya</h1>
        <div class="row">
                <div class=" col-sm-4">
                    <div class="card-main img-box">
                        <img class="card-img-top img-responsive" src="./assets/img/conjuly3plus.jpg" alt="Card image cap">
                        <div class="text-view">
                            <ul>
                                <a href="#"><p>Selanjutnya</p></a>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class=" col-sm-4">
                    <div class="card-main img-box">
                        <img class="card-img-top img-responsive" src="./assets/img/conjuly3plus.jpg" alt="Card image cap">
                        <div class="text-view">
                            <ul>
                                <a href="#"><p>Selanjutnya</p></a>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class=" col-sm-4">
                    <div class="card-main img-box">
                        <img class="card-img-top img-responsive" src="./assets/img/conjuly6plus.jpg" alt="Card image cap">
                        <div class="text-view">
                            <ul>
                                <a href="#"><p>Selanjutnya</p></a>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php 
include("footer.php");
?>