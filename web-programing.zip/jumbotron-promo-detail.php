<div class="jumbotron jumbotron-fluid">
  <div class="jumbotron-promo-detail">
      <div class="fullwidth-layout background-promo-detail">
        
      </div>
      
  </div>
</div>