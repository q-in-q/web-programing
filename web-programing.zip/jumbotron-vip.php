<div class="jumbotron jumbotron-fluid">
  <div class="jumbotron-child-pro">
      <div class="container jumbotron-content-main text-center">
            <h1>Nimkati Pelayanan VIP dari Kami</h1>
      </div>
  </div>
</div>